import { Text, View, StyleSheet, Image,  SafeAreaView, Button  } from 'react-native';

 export default function AssetExample(){
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        
      </Text>
      <Image style={styles.logo} source={require('../assets/58516_star-wars-episode-iv-a-new-hope-original-160932.jpg')} />

      <Text style={styles.paragraph}>
        Star wars teve grande impacto no cultura pop após seu lançamento em 1977.
      </Text>
      <Image style={styles.logo} source={require('../assets/58516_et.jpeg')} />
        <Text style={styles.paragraph}>
        Quase três gerações depois o filme “E.T. O Extraterrestre” (1982) continua emocionando, tornando-se um clássico 
      </Text>


  </View>
       
  );
}
   const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  paragraph: {
    margin: 24,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
    
  },
  logo: {
    height: 148,
    width: 208,
  }
  
});
